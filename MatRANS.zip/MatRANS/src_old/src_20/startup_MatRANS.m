% startup script to add MatRANS source code to Matlab's path 
%addpath C:\Users\Startuser\Documents\Matlab\MatRANS_r20\src; % Example
addpath C:\Path\To\MatRANS_r20\src; % Change this to your location